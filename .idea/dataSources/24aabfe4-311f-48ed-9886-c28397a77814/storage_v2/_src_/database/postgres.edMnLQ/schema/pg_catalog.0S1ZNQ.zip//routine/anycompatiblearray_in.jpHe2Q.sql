create function anycompatiblearray_in(cstring) returns anycompatiblearray
    language internal
as
$$anycompatiblearray_in$$;

comment on function anycompatiblearray_in(cstring) is 'I/O';

