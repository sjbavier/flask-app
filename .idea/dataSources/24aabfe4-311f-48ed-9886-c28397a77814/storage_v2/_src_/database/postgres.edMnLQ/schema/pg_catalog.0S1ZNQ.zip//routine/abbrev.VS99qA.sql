create function abbrev(cidr) returns text
    language internal
as
$$cidr_abbrev$$;

comment on function abbrev(inet) is 'abbreviated display of inet value';

