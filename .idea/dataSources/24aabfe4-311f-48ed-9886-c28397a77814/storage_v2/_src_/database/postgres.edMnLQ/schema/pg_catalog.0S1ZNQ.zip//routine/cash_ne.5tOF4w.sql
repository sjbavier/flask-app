create function cash_ne(money, money) returns boolean
    language internal
as
$$cash_ne$$;

comment on function cash_ne(money, money) is 'implementation of <> operator';

