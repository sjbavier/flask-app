create function brin_minmax_multi_distance_int8(internal, internal) returns double precision
    language internal
as
$$brin_minmax_multi_distance_int8$$;

comment on function brin_minmax_multi_distance_int8(internal, internal) is 'BRIN multi minmax int8 distance';

