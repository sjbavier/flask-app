create function brin_minmax_union(internal, internal, internal) returns boolean
    language internal
as
$$brin_minmax_union$$;

comment on function brin_minmax_union(internal, internal, internal) is 'BRIN minmax support';

