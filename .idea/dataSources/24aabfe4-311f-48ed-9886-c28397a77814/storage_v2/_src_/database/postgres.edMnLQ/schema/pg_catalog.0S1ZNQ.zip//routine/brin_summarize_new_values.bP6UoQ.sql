create function brin_summarize_new_values(regclass) returns integer
    language internal
as
$$brin_summarize_new_values$$;

comment on function brin_summarize_new_values(regclass) is 'brin: standalone scan new table pages';

