create function circle_recv(internal) returns circle
    language internal
as
$$circle_recv$$;

comment on function circle_recv(internal) is 'I/O';

