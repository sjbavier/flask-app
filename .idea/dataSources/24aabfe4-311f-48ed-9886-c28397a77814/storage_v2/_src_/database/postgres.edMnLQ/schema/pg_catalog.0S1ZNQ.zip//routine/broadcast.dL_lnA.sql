create function broadcast(inet) returns inet
    language internal
as
$$network_broadcast$$;

comment on function broadcast(inet) is 'broadcast address of network';

