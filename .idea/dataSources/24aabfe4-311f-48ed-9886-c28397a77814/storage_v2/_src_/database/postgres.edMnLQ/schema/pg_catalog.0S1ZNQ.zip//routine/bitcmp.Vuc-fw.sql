create function bitcmp(bit, bit) returns integer
    language internal
as
$$bitcmp$$;

comment on function bitcmp(bit, bit) is 'less-equal-greater';

