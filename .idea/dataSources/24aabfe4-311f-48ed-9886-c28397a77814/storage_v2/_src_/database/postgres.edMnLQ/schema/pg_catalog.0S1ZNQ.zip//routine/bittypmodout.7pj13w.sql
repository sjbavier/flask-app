create function bittypmodout(integer) returns cstring
    language internal
as
$$bittypmodout$$;

comment on function bittypmodout(int4) is 'I/O typmod';

