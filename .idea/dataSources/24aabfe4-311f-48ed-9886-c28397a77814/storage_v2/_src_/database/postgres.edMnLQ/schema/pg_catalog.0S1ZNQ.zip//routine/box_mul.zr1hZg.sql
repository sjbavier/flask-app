create function box_mul(box, point) returns box
    language internal
as
$$box_mul$$;

comment on function box_mul(box, point) is 'implementation of * operator';

