create function bool(integer) returns boolean
    language internal
as
$$int4_bool$$;

comment on function bool(int4) is 'convert int4 to boolean';

