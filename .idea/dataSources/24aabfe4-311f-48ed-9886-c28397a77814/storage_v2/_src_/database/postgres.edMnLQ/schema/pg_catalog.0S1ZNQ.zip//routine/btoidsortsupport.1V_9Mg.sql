create function btoidsortsupport(internal) returns void
    language internal
as
$$btoidsortsupport$$;

comment on function btoidsortsupport(internal) is 'sort support';

