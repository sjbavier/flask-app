create function _pg_numeric_precision(typid oid, typmod integer) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

