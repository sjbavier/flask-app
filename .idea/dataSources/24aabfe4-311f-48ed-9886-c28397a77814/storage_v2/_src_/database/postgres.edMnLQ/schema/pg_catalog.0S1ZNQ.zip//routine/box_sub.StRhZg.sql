create function box_sub(box, point) returns box
    language internal
as
$$box_sub$$;

comment on function box_sub(box, point) is 'implementation of - operator';

