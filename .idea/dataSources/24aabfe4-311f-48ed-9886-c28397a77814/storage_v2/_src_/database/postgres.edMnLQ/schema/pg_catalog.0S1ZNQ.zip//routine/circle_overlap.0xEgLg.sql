create function circle_overlap(circle, circle) returns boolean
    language internal
as
$$circle_overlap$$;

comment on function circle_overlap(circle, circle) is 'implementation of && operator';

