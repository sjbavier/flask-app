create function abs(real) returns real
    language internal
as
$$float4abs$$;

comment on function abs(int4) is 'absolute value';

