create function anycompatiblemultirange_in(cstring, oid, integer) returns anycompatiblemultirange
    language internal
as
$$anycompatiblemultirange_in$$;

comment on function anycompatiblemultirange_in(cstring, oid, int4) is 'I/O';

