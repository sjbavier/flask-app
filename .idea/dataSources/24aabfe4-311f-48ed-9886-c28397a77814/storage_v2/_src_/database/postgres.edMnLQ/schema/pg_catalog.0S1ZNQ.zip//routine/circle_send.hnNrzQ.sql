create function circle_send(circle) returns bytea
    language internal
as
$$circle_send$$;

comment on function circle_send(circle) is 'I/O';

