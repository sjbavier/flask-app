create function cash_mi(money, money) returns money
    language internal
as
$$cash_mi$$;

comment on function cash_mi(money, money) is 'implementation of - operator';

