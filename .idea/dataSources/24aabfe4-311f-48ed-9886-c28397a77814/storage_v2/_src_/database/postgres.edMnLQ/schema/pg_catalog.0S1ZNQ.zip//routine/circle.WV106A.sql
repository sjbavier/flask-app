create function circle(point, double precision) returns circle
    language internal
as
$$cr_circle$$;

comment on function circle(polygon) is 'convert polygon to circle';

