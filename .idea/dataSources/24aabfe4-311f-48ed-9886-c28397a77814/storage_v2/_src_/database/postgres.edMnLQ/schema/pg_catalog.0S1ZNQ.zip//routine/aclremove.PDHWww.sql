create function aclremove(aclitem[], aclitem) returns aclitem[]
    language internal
as
$$aclremove$$;

comment on function aclremove(_aclitem, aclitem) is 'remove ACL item';

