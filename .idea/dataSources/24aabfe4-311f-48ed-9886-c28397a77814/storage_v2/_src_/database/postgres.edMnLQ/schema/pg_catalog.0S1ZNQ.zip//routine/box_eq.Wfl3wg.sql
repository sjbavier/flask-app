create function box_eq(box, box) returns boolean
    language internal
as
$$box_eq$$;

comment on function box_eq(box, box) is 'implementation of = operator';

