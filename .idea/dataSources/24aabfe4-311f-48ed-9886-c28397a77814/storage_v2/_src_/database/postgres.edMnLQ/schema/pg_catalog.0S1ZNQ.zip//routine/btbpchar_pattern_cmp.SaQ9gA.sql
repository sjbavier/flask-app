create function btbpchar_pattern_cmp(character, character) returns integer
    language internal
as
$$btbpchar_pattern_cmp$$;

comment on function btbpchar_pattern_cmp(bpchar, bpchar) is 'less-equal-greater';

