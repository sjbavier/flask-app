create function bool_alltrue(internal) returns boolean
    language internal
as
$$bool_alltrue$$;

comment on function bool_alltrue(internal) is 'aggregate final function';

