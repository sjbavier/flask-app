create function currtid2(text, tid) returns tid
    language internal
as
$$currtid_byrelname$$;

comment on function currtid2(text, tid) is 'latest tid of a tuple';

