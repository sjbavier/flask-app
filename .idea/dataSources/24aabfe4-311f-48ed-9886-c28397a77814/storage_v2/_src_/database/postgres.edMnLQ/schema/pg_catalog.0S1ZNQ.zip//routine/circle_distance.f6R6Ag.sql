create function circle_distance(circle, circle) returns double precision
    language internal
as
$$circle_distance$$;

comment on function circle_distance(circle, circle) is 'implementation of <-> operator';

