create function chareq("char", "char") returns boolean
    language internal
as
$$chareq$$;

comment on function chareq("char", "char") is 'implementation of = operator';

