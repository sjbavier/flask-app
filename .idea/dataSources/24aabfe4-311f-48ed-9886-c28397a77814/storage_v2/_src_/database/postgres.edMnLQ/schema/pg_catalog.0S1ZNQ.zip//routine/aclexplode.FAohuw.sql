create function aclexplode(acl aclitem[], OUT grantor oid, OUT grantee oid, OUT privilege_type text, OUT is_grantable boolean) returns SETOF record
    language internal
as
$$aclexplode$$;

comment on function aclexplode(_aclitem, out oid, out oid, out text, out bool) is 'convert ACL item array to table, primarily for use by information schema';

